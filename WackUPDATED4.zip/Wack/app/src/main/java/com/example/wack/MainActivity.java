package com.example.wack;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    ImageView image1;
    ImageView image2;
    ImageView image3;
    ImageView image4;
    ImageView image5;
    ImageView image6;
    ImageView image7;
    ImageView image8;
    ImageView image9;
    ImageView board;

    TextView text;
    TextView TimerWindow;

    Timer timer;
    TimerTask timerthread;

    int CurrentTime = 60;
    int rarity = 20;

    ArrayList<Target> targetList = new ArrayList<Target>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Target t1 = new Target(R.drawable.meme);
        targetList.add(t1);
        Target t2 = new Target(R.drawable.meme);
        targetList.add(t2);
        Target t3 = new Target(R.drawable.meme);
        targetList.add(t3);
        Target t4 = new Target(R.drawable.meme);
        targetList.add(t4);
        Target t5 = new Target(R.drawable.meme);
        targetList.add(t5);
        Target t6 = new Target(R.drawable.meme);
        targetList.add(t6);
        Target t7 = new Target(R.drawable.meme);
        targetList.add(t7);
        Target t8 = new Target(R.drawable.meme);
        targetList.add(t8);
        Target t9 = new Target(R.drawable.meme);
        targetList.add(t9);

        text = findViewById(R.id.textView);
        TimerWindow = findViewById(R.id.textView2);

        timerthread = new TimerTask() {
            @Override
            public void run() {
                if (CurrentTime > 0) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            CurrentTime--;
                            TimerWindow.setText("" + CurrentTime);

                            for(int i = 0; i < targetList.size(); i++) {
                                //LOOP_________________________________________________

                                if (targetList.get(i).getTimeBoolean()) {
                                    targetList.get(i).setTimeAppear(CurrentTime - (int) ((Math.random() * rarity) + 1));
                                    targetList.get(i).setTimeBoolean(false);
                                }
                                if (CurrentTime == targetList.get(i).getTimeAppear()) {
                                    resetImage(i);
                                    targetappear(i, targetList.get(i));
                                    targetList.get(i).setTimeDissapear(CurrentTime - (int) ((Math.random() * 6) + 3));
                                }
                                if (CurrentTime == targetList.get(i).getTimeDissapear()) {
                                    if (targetList.get(i).getAppearance())
                                        targetdisappear(i, targetList.get(i));

                                    targetList.get(i).setTimeAppear(CurrentTime - (int) ((Math.random() * rarity) + 1));
                                }

                                //LOOP_________________________________________________
                            }

                            if(CurrentTime < 40){
                                rarity = 15;
                            }
                            if(CurrentTime < 20){
                                rarity = 8;
                            }
                        }
                    });
                }
            }
        };

        setImageID();
        pairObjectImages(image1, t1);
        pairObjectImages(image2, t2);
        pairObjectImages(image3, t3);
        pairObjectImages(image4, t4);
        pairObjectImages(image5, t5);
        pairObjectImages(image6, t6);
        pairObjectImages(image7, t7);
        pairObjectImages(image8, t8);
        pairObjectImages(image9, t9);

        image1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                targetHit(image1, t1);
            }
        });
        image2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                targetHit(image2, t2);
            }
        });
        image3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                targetHit(image3, t3);
            }
        });
        image4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                targetHit(image4, t4);
            }
        });
        image5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                targetHit(image5, t5);
            }
        });
        image6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                targetHit(image6, t6);
            }
        });
        image7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                targetHit(image7, t7);
            }
        });
        image8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                targetHit(image8, t8);
            }
        });
        image9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                targetHit(image9, t9);
            }
        });

        timer = new Timer(true);
        timer.scheduleAtFixedRate(timerthread, 0,1000);

    }

    public void pairObjectImages(ImageView i, Target t){
        i.setImageResource(t.getImageID());
    }

    public void setImageID(){
        image1 = findViewById(R.id.target1);
        imageresources(image1, R.drawable.meme);
        image2 = findViewById(R.id.target2);
        imageresources(image2, R.drawable.meme);
        image3 = findViewById(R.id.target3);
        imageresources(image3, R.drawable.meme);
        image4 = findViewById(R.id.target4);
        imageresources(image4, R.drawable.meme);
        image5 = findViewById(R.id.target5);
        imageresources(image5, R.drawable.meme);
        image6 = findViewById(R.id.target6);
        imageresources(image6, R.drawable.meme);
        image7 = findViewById(R.id.target7);
        imageresources(image7, R.drawable.meme);
        image8 = findViewById(R.id.target8);
        imageresources(image8, R.drawable.meme);
        image9 = findViewById(R.id.target9);
        imageresources(image9, R.drawable.meme);
        board = findViewById(R.id.MainBoard);
        imageresources(board, R.drawable.pitboard);
    }

    public void imageresources(ImageView I, int id){
        I.setImageResource(id);
        if(id != R.drawable.pitboard)
        I.setVisibility(View.INVISIBLE);
    }

    public void targetappear(int i, Target t1){

        if(i == 0){
            image1.setVisibility(View.VISIBLE);
            image1.startAnimation(t1.getAppearAnimation());
        }
        if(i == 1){
            image2.setVisibility(View.VISIBLE);
            image2.startAnimation(t1.getAppearAnimation());
        }
        if(i == 2){
            image3.setVisibility(View.VISIBLE);
            image3.startAnimation(t1.getAppearAnimation());
        }
        if(i == 3){
            image4.setVisibility(View.VISIBLE);
            image4.startAnimation(t1.getAppearAnimation());
        }
        if(i == 4){
            image5.setVisibility(View.VISIBLE);
            image5.startAnimation(t1.getAppearAnimation());
        }
        if(i == 5){
            image6.setVisibility(View.VISIBLE);
            image6.startAnimation(t1.getAppearAnimation());
        }
        if(i == 6){
            image7.setVisibility(View.VISIBLE);
            image7.startAnimation(t1.getAppearAnimation());
        }
        if(i == 7){
            image8.setVisibility(View.VISIBLE);
            image8.startAnimation(t1.getAppearAnimation());
        }
        if(i == 8){
            image9.setVisibility(View.VISIBLE);
            image9.startAnimation(t1.getAppearAnimation());
        }
        t1.setAppearance(true);
    }

    public void resetImage(int i){

        if(i == 0){
            image1.setImageResource(R.drawable.meme);
        }
        if(i == 1){
            image2.setImageResource(R.drawable.meme);
        }
        if(i == 2){
            image3.setImageResource(R.drawable.meme);
        }
        if(i == 3){
            image4.setImageResource(R.drawable.meme);
        }
        if(i == 4){
            image5.setImageResource(R.drawable.meme);
        }
        if(i == 5){
            image6.setImageResource(R.drawable.meme);
        }
        if(i == 6){
            image7.setImageResource(R.drawable.meme);
        }
        if(i == 7){
            image8.setImageResource(R.drawable.meme);
        }
        if(i == 8) {
            image9.setImageResource(R.drawable.meme);
        }

    }

    public void targetdisappear(int i, Target t1){

        if(i == 0){
            image1.setVisibility(View.INVISIBLE);
            image1.startAnimation(t1.getDisappearAnimation());
        }
        if(i == 1){
            image2.setVisibility(View.INVISIBLE);
            image2.startAnimation(t1.getDisappearAnimation());
        }
        if(i == 2){
            image3.setVisibility(View.INVISIBLE);
            image3.startAnimation(t1.getDisappearAnimation());
        }
        if(i == 3){
            image4.setVisibility(View.INVISIBLE);
            image4.startAnimation(t1.getDisappearAnimation());
        }
        if(i == 4){
            image5.setVisibility(View.INVISIBLE);
            image5.startAnimation(t1.getDisappearAnimation());
        }
        if(i == 5){
            image6.setVisibility(View.INVISIBLE);
            image6.startAnimation(t1.getDisappearAnimation());
        }
        if(i == 6){
            image7.setVisibility(View.INVISIBLE);
            image7.startAnimation(t1.getDisappearAnimation());
        }
        if(i == 7){
            image8.setVisibility(View.INVISIBLE);
            image8.startAnimation(t1.getDisappearAnimation());
        }
        if(i == 8){
            image9.setVisibility(View.INVISIBLE);
            image9.startAnimation(t1.getDisappearAnimation());
        }
        t1.setAppearance(false);
    }

    public void targetHit(ImageView i1, Target t1){

        i1.setVisibility(View.INVISIBLE);
        i1.setImageResource(R.drawable.uncannymeme);
        i1.startAnimation(t1.getDisappearAnimation());
        t1.setAppearance(false);

    }
}

