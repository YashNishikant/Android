package com.example.final_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class SignInScreen extends AppCompatActivity {

    EditText username;
    EditText password;
    Button signInButton;

    ArrayList userlist = new ArrayList();

    private static String usernametxt;
    private String passwordtxt;
    public static String key = "c743270j4283cj0982v5j75908j7v245-70864";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_screen);

        userlist = MainWorkoutActivity.DataAccessObject.getUsers();

        signInButton = findViewById(R.id.id_button_signIn);
        username = findViewById(R.id.id_edittext_username);
        password = findViewById(R.id.id_edittext_password);

        username.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                usernametxt = charSequence.toString();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                passwordtxt = charSequence.toString();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(usernametxt.isEmpty()){
                    Toast("Please enter a username");
                    return;
                }

                if(usernametxt.contains(" ") || passwordtxt.contains(" ")){
                    Toast("Do Not Use Spaces");
                }

                if(!usernametxt.isEmpty() && !usernametxt.contains(" ") && !passwordtxt.contains(" ")){
                    Intent signOnIn = new Intent(SignInScreen.this, StartScreen.class);

                    if(returningUser(userlist, getUsername()))
                        signOnIn.putExtra(key, "Welcome Back " + getUsername() + "!");
                    else
                        signOnIn.putExtra(key, "New Account Created. Welcome " + getUsername() + "!");

                    startActivity(signOnIn);
                }
            }
        });

    }

    public boolean returningUser(ArrayList users, String name){
        for(int i = 0; i < users.size(); i++){
            if(users.get(i).equals(name)){
                return true;
            }
        }
        return false;
    }

    public static String getUsername(){
        return usernametxt;
    }

    void Toast(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

}